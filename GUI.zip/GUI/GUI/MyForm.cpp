#include "MyForm.h"
//#include<Windows.h>
//using namespace System;
//using namespace System::Windows::Forms;
//
//int WINAPI WinMain(HINSTANCE hinst, HINSTANCE hPrecInst, LPSTR args , int ncmdshow) {
//	GUI::Application::EnableVisualStyles();
//	GUI::Application::SetCompatibleTextRenderingDefault(false);
//	GUI::Application::Run(gcnew GUI::MyForm());
//	return 0;
//}
