//#include"MyForm.h"
//#include"MyForm1.h"
//#include"MyForm2.h"
//#include<Windows.h>
////
////using namespace System;
////using namespace System::Windows::Forms;
////
////[STAThreadAttribute]
////void main(array<String^>^ args) {
////    Application::EnableVisualStyles();
////    Application::SetCompatibleTextRenderingDefault(false);
////    //WinformCDemo is your project name
////    GUI::MyForm form;
////    Application::Run(% form);
////}